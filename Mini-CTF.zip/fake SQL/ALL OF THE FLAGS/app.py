from flask import Flask, request, abort, session
import sqlite3

a = Flask(__name__)
a.secret_key = 'super_secret_key_for_sessions'

@a.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        u = request.form.get('username')
        p = request.form.get('password')
        c = sqlite3.connect('db.sqlite')
        r = c.execute(f"SELECT * FROM users WHERE username='{u}' AND password='{p}';").fetchall()
        if len(r) > 0:
            session['authenticated'] = True
            return 'CLOSE THIS PAGE: It seems the password is hidden in plain sight.'
        else:
            abort(500)
    return open('index.html').read()

@a.route('/secretpath/7a/92/hiddenflag', methods=['GET'])
def hidden_flag():
    if not session.get('authenticated'):
        abort(403)
    try:
        with open('.hidden_ctf/flag.txt', 'r') as f:
            return f.read().strip()
    except:
        abort(500)

if __name__ == '__main__':
    a.run(host='127.0.0.1', port=5000)
