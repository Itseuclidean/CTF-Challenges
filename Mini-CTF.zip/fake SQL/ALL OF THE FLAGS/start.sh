#!/bin/bash
python3 init_db.py
python3 app.py