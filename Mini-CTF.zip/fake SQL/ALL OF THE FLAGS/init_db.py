import sqlite3

conn = sqlite3.connect('db.sqlite')
c = conn.cursor()
c.execute('CREATE TABLE IF NOT EXISTS users (username TEXT, password TEXT)')
c.execute('INSERT INTO users (username, password) VALUES ("admin", "password")')
conn.commit()
conn.close()